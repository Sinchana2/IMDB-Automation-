import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TopRatedMovies {
	
	public static void main(String args[]) throws InterruptedException
	{
	        System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
	    	
			// SignUp page variables
			String baseUrl = "http://imdb.com";
	        String PageName="Create account";
            String Page1Label1="Your name";
            String Page1Label2="Email";
            String Page1Label3="Password";
            String Page1Label4="Re-enter Password";
            
            // Sign-in page variables
            String Page2Label1= "Sign-in";
    		String Label1xpath= "//*[@id=\"authportal-main-section\"]/div[2]/div/div/form/div/div/div/h1";
    		String Page2Label2="E-mail";
    		String Label2xpath="//*[@id=\"authportal-main-section\"]/div[2]/div/div/form/div/div/div/div[1]/label";
    		String TextBox1xpath="//*[@id=\"ap_email\"]";
    		String Page2Label3="Password";
    		String Label3xpath="//*[@id=\"authportal-main-section\"]/div[2]/div/div/form/div/div/div/div[2]/div[1]/div[1]/label";
    		String TextBox2xpath="//*[@id=\"ap_password\"]";
    		String SignInButton="//*[@id=\"signInSubmit\"]";
    		
    		// Top Rated Movies Page variables
    		String Menu="//*[@id=\"imdbHeader-navDrawerOpen\"]/svg";
    		String Movies="//*[@id=\"imdbHeader\"]/div[2]/aside/div/div[2]/div/div[1]/span/label/span[2]";
            String TopMovies="//*[@id=\"imdbHeader\"]/div[2]/aside/div/div[2]/div/div[1]/span/div/div/ul/a[3]";
            String sortBy="//*[@id=\"lister-sort-by-options\"]";
            String LastSorted="//*[@id=\"main\"]/div/span/div/div/div[3]/table/tbody/tr[250]/td[2]/a";
            String ReleaseDate="//*[@id=\"__next\"]/main/div/section[1]/div/section/div/div[1]/section[9]/div[2]/ul/li[1]/div/ul/li/a";
            
    		
    		
	        // launch Chrome and direct it to the Base URL
	        driver.get(baseUrl);
	        
	        // Wait for the page to load
	        @SuppressWarnings("deprecation")
			WebDriverWait wait = new WebDriverWait(driver,50);
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"imdbHeader\"]/div[2]/div[5]/a")));
	        
	        // Click on the Signin link
	        driver.findElement(By.xpath("//*[@id=\"imdbHeader\"]/div[2]/div[5]/a")).click();
	        
	        // Click on SIgnin with IMDB
	        /*WebDriverWait wait2 = new WebDriverWait(driver,50);*/
	        wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"signin-options\"]/div/div[1]/a[1]"))));
	        driver.findElement(By.xpath("/*[@id=\\\"signin-options\\\"]/div/div[1]/a[1]")).click();
	        
	        // Click on create a new IMDB account
	       
	        wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\\\"createAccountSubmit\\"))));
	        driver.findElement(By.xpath("//*[@id=\"createAccountSubmit\"]")).click();
	        
	        // Verify the page header
	        
	        wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"ap_register_form\"]/div/div/h1"))));
	        String Label=driver.findElement(By.xpath("//*[@id=\"ap_register_form\"]/div/div/h1")).getText();
	        if (Label.contentEquals(PageName)){
	            System.out.println("We are in Create account page");
	        } else {
	            System.out.println("Fail to load page");
	        }
	       
	        
	        // Validate the display of label Your Name
	        String Label1=driver.findElement(By.xpath("//div[@class='a-row a-spacing-base']/label[text()='Your name']")).getText();
	    
	        if (Label1.contentEquals(Page1Label1)){
	            System.out.println("Label1 Test Passed!");
	        } else {
	            System.out.println("Label1 Test Failed");
	        }
	        
	        
	      // Validate the display of label Email
	        String Label2=driver.findElement(By.xpath("//*[@id=\"ap_register_form\"]/div/div/div[2]/div/label")).getText();
	        
	        if (Label2.contentEquals(Page1Label2)){
	            System.out.println("Label2 Test Passed!");
	        } else {
	            System.out.println("Label2 Test Failed");
	        }
	        
	      // Validate the display of label Password
	        String Label3=driver.findElement(By.xpath("//*[@id=\"ap_register_form\"]/div/div/div[3]/div[1]/label")).getText();
	        
	        if (Label3.contentEquals(Page1Label3)){
	            System.out.println("Label3 Test Passed!");
	        } else {
	            System.out.println("Label3 Test Failed");
	        }
	        
		   // Validate the display of label Re-enter Password
	        String Label4=driver.findElement(By.xpath("//*[@id=\"ap_register_form\"]/div/div/div[3]/div[2]/label")).getText();
	        
	        if (Label4.contentEquals(Page1Label4)){
	            System.out.println("Label4 Test Passed!");
	        } else {
	            System.out.println("Label4 Test Failed");
	        }
	        
	     // Verify the functionality with invalid characters for all the fields
	        WebElement Label1TextBox=driver.findElement(By.xpath("//*[@id=\"ap_customer_name\"]"));
	        Label1TextBox.sendKeys("test&%$123");
	        WebElement Label2TextBox=driver.findElement(By.xpath("//*[@id=\"ap_email\"]"));
	        Label2TextBox.sendKeys("testing.jobs2gmail.com");
	        WebElement Label3TextBox=driver.findElement(By.xpath("//*[@id=\"ap_password\"]"));
	        Label3TextBox.sendKeys("test#123");
	        WebElement Label4TextBox=driver.findElement(By.xpath("//*[@id=\"ap_password_check\"]"));
	        Label4TextBox.sendKeys("test#13");
	        driver.findElement(By.id("continue")).click();
	        
	      // Verify the error messages
	        String Error1=driver.findElement(By.xpath("//*[@id=\"auth-error-message-box\"]/div/div/dl/li[1]/span")).getText();
	        System.out.printf("For Invalid Email: ",Error1);
	        String Error2=driver.findElement(By.xpath("//*[@id=\"auth-error-message-box\"]/div/div/dl/li[2]")).getText();
	        System.out.printf("For Invalid Password: ",Error2);
	        String Error3=driver.findElement(By.xpath("//*[@id=\"auth-warning-message-box\"]/div/div/ul/li/span")).getText();
	        System.out.printf("For entering already existing Email: ",Error3);
	        
	      //Verifying with another set of invalid characters
	        //Entering more than 50 chars- By default the text box wont allow you to enter >50 chars
	        Label1TextBox.sendKeys("test&%$123dhfsueyuryyyytbxshhhhhhhhhhhhhhskkkkkkkkkkkkkkkhssssssssss");
	       
	        //Verify for empty data 
	       driver.findElement(By.xpath("//*[@id=\"ap_customer_name\"]")).clear();
	        Label1TextBox.sendKeys("");
	        driver.findElement(By.xpath("//*[@id=\"ap_email\"]")).clear();
	        Label2TextBox.sendKeys("");
	        driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).clear();
	        Label3TextBox.sendKeys("");
	        driver.findElement(By.xpath("//*[@id=\"ap_password_check\"]")).clear();
	        Label4TextBox.sendKeys("");
	        driver.findElement(By.id("continue")).click();
	        
	       // Verify the Error message for second set of Empty data
	        String Error4=driver.findElement(By.xpath("//*[@id=\"auth-error-message-box\"]/div/div/dl/li[1]/span")).getText();
	        System.out.printf("For Invalid name: ",Error4);
	        String Error5=driver.findElement(By.xpath("//*[@id=\"auth-error-message-box\"]/div/div/dl/li[2]")).getText();
	        System.out.printf("For Invalid Password: ",Error5);
	        String Error6=driver.findElement(By.xpath("//*[@id=\"auth-warning-message-box\"]/div/div/ul/li/span")).getText();
	        System.out.printf("For entering already existing Email: ",Error6);
	        
	       // Verify the functionality with valid characters for all the fields
	        driver.findElement(By.xpath("//*[@id=\"ap_customer_name\"]")).sendKeys("test123");
	        
	        driver.findElement(By.xpath("//*[@id=\"ap_email\"]")).sendKeys("testing.jobs2@gmail.com");
	        
	        driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys("test#123");
	 
	        driver.findElement(By.xpath("//*[@id=\"ap_password_check\"]")).sendKeys("test#123");
	    
	        driver.findElement(By.id("continue")).click();
	    
	        //Testing Signin page    
		/*
		String SignInLabel=driver.findElement(By.xpath(Label1xpath)).getText();
		if (SignInLabel.contentEquals(Page2Label1)){
            System.out.println("Label1 Test Passed!");
        } else {
            System.out.println("Label1 Test Failed");
        }
		
		//Validating Email Label
		
		String EmailLabel=driver.findElement(By.xpath(Label2xpath)).getText();
		if (EmailLabel.contentEquals(Page2Label2)){
            System.out.println("Label2 Test Passed!");
        } else {
            System.out.println("Label2 Test Failed");
        }
		
		//Validating Password Label
		
		String PasswordLabel=driver.findElement(By.xpath(Label3xpath)).getText();
		if (PasswordLabel.contentEquals(Page2Label3)){
		    System.out.println("Label3 Test Passed!");
		} else {
	        System.out.println("Label3 Test Failed");
        }
		
		driver.findElement(By.xpath(TextBox1xpath)).sendKeys("testing.jobs2@gmail.com");
		driver.findElement(By.xpath(TextBox2xpath)).sendKeys("test#123");
		driver.findElement(By.xpath(SignInButton)).click();
		
	}*/
	    // Testing Home Page    
	    driver.findElement(By.xpath(Menu)).click();
	    driver.findElement(By.xpath(Movies)).click();
	    driver.findElement(By.xpath(TopMovies)).click();
	    System.out.println("Clicking on the drop down");
	    WebElement dropdn = driver.findElement(By.xpath(sortBy));
        dropdn.click();
    	Select se = new Select(dropdn);
    	se.selectByVisibleText("Release Date");
    	driver.findElement(By.xpath(LastSorted)).click();
    	String Release_Date=driver.findElement(By.xpath(ReleaseDate)).getText();
    	  
    	String[] words=Release_Date.split("\\s");//splits the string based on whitespace  
    	//using java foreach loop to print elements of string array  
    	System.out.printf("The Release Date is: ");
    	for(String w:words){  
    	System.out.println(w);  
    	}  
    
    	
    	driver.close();

    	}
	    
	}

